// ── Memento ─────────────────────────────────────────────────
// Guarda una "foto" del equipo completo de Steve en un momento dado.
// Nadie puede modificar su contenido desde afuera.

class Memento {
  constructor(nombre, selArmadura, selArmas) {
    this._nombre     = nombre;
    this._selArmadura = { ...selArmadura }; // copia para no mutar
    this._selArmas    = { ...selArmas };
    this._fecha       = new Date().toLocaleTimeString();
  }

  getNombre()      { return this._nombre; }
  getSelArmadura() { return { ...this._selArmadura }; }
  getSelArmas()    { return { ...this._selArmas }; }
  getFecha()       { return this._fecha; }

  // Resumen legible del perfil guardado
  getResumen() {
    const piezas = Object.entries(this._selArmadura)
      .filter(([, v]) => v)
      .map(([k, v]) => `${k}: ${v}`)
      .join(', ');

    const armas = Object.entries(this._selArmas)
      .filter(([, v]) => v)
      .map(([k, v]) => `${k}: ${v}`)
      .join(', ');

    return [piezas, armas].filter(Boolean).join(' | ') || 'Sin equipo';
  }
}

export default Memento;