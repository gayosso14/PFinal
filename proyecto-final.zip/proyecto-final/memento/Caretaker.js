import Memento from './Memento';

// ── Caretaker ────────────────────────────────────────────────
// Administra todos los perfiles guardados.
// No sabe qué hay adentro de cada Memento, solo los guarda y entrega.

class Caretaker {
  constructor() {
    this._perfiles = []; // Array de Mementos
  }

  // Guarda un nuevo perfil con nombre
  guardar(nombre, selArmadura, selArmas) {
    // Si ya existe un perfil con ese nombre, lo reemplaza
    const idx = this._perfiles.findIndex(m => m.getNombre() === nombre);
    const memento = new Memento(nombre, selArmadura, selArmas);

    if (idx >= 0) {
      this._perfiles[idx] = memento;
    } else {
      this._perfiles.push(memento);
    }

    return memento;
  }

  // Devuelve un perfil por nombre
  cargar(nombre) {
    return this._perfiles.find(m => m.getNombre() === nombre) || null;
  }

  // Elimina un perfil por nombre
  eliminar(nombre) {
    this._perfiles = this._perfiles.filter(m => m.getNombre() !== nombre);
  }

  // Devuelve todos los perfiles
  getTodos() {
    return [...this._perfiles];
  }

  // Cuántos perfiles hay guardados
  getCantidad() {
    return this._perfiles.length;
  }
}

export default Caretaker;