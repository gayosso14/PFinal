class IArma {
  constructor(nombre, emoji, rareza, rarityColor) {
    this.nombre      = nombre;
    this.emoji       = emoji;
    this.rareza      = rareza;
    this.rarityColor = rarityColor;
  }

  getDanio()       { return 0; }
  getDurabilidad() { return 0; }
  getCosto()       { return 0; }
  getDescripcion() { return ''; }
}

export default IArma;