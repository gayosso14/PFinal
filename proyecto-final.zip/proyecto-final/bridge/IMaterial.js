class IMaterial {
  constructor(nombre, emoji, rareza, rarityColor) {
    this.nombre      = nombre;
    this.emoji       = emoji;
    this.rareza      = rareza;
    this.rarityColor = rarityColor;
  }

  getDefensa()     { return 0; }
  getDurabilidad() { return 0; }
  getCosto()       { return 0; }
  getDescripcion() { return ''; }
}
 
export default IMaterial;