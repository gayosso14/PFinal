import { useState, useRef } from 'react';

import PersonajeBase from '../decorator/PersonajeBase';
import PiezaFactory  from '../factory/PiezaFactory';
import ArmaFactory   from '../factory/ArmaFactory';
import Caretaker     from '../memento/Caretaker';

// ── Constantes ───────────────────────────────────────────────
export const MONEDAS_INICIO = 550;

export const ARMOR_SLOTS = [
  { id: 'casco', label: 'Casco', emoji: '⛑️' },
  { id: 'pecho', label: 'Pecho', emoji: '🦺' },
  { id: 'botas', label: 'Botas', emoji: '👢' },
];

export const WEAPON_SLOTS = [
  { id: 'espada', label: 'Espada', emoji: '🗡️' },
  { id: 'arco',   label: 'Arco',   emoji: '🏹' },
  { id: 'hacha',  label: 'Hacha',  emoji: '🪓' },
];

// ── Model: construye el personaje con Factory + Decorator + Bridge ──
function buildPersonaje(selArmadura, selArmas) {
  let personaje = new PersonajeBase();

  ['casco', 'pecho', 'botas'].forEach(slot => {
    const mat = selArmadura[slot];
    if (mat) personaje = PiezaFactory.crear(personaje, slot, mat);
  });

  ['espada', 'arco', 'hacha'].forEach(slot => {
    const mat = selArmas[slot];
    if (mat) personaje = ArmaFactory.crear(personaje, slot, mat);
  });

  return personaje;
}

// ── ViewModel ────────────────────────────────────────────────
// Contiene todo el estado y la lógica del equipamiento.
// La Vista (EquipmentScreen) solo consume lo que este hook expone.

export function useEquipamiento() {

  // ── Estado ───────────────────────────────────────────────
  const [selArmadura, setSelArmadura] = useState({
    casco: null, pecho: null, botas: null,
  });
  const [selArmas, setSelArmas] = useState({
    espada: null, arco: null, hacha: null,
  });
  const [tab, setTab] = useState('armadura');

  // Caretaker (Memento) en ref para que no se recree en cada render
  const caretaker = useRef(new Caretaker()).current;

  // ── Datos derivados (Model → ViewModel) ─────────────────
  const personaje   = buildPersonaje(selArmadura, selArmas);
  const costoTotal  = personaje.getCostoTotal();
  const monedasLeft = MONEDAS_INICIO - costoTotal;
  const equipados   = [
    ...Object.values(selArmadura),
    ...Object.values(selArmas),
  ].filter(Boolean).length;

  const pocasMonedas  = monedasLeft < 80 && monedasLeft > 0;
  const sinMonedas    = monedasLeft <= 0;

  // ── Acciones ─────────────────────────────────────────────
  const seleccionarArmadura = (slot, mat) =>
    setSelArmadura(prev => ({ ...prev, [slot]: mat }));

  const seleccionarArma = (slot, mat) =>
    setSelArmas(prev => ({ ...prev, [slot]: mat }));

  const resetear = () => {
    setSelArmadura({ casco: null, pecho: null, botas: null });
    setSelArmas({ espada: null, arco: null, hacha: null });
  };

  const cargarPerfil = (newSelArmadura, newSelArmas) => {
    setSelArmadura(newSelArmadura);
    setSelArmas(newSelArmas);
    setTab('armadura');
  };

  // ── Lo que expone el ViewModel a la Vista ────────────────
  return {
    // Estado
    selArmadura,
    selArmas,
    tab,
    setTab,

    // Datos derivados
    personaje,
    costoTotal,
    monedasLeft,
    equipados,
    pocasMonedas,
    sinMonedas,

    // Memento
    caretaker,

    // Acciones
    seleccionarArmadura,
    seleccionarArma,
    resetear,
    cargarPerfil,
  };
}