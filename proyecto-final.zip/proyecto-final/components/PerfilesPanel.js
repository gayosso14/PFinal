import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView,
} from 'react-native';
import THEME from '../config/theme';

export default function PerfilesPanel({ caretaker, selArmadura, selArmas, onCargar }) {
  const [nombre, setNombre]       = useState('');
  const [mensaje, setMensaje]     = useState(null); // { texto, tipo: 'ok'|'err' }
  const [perfiles, setPerfiles]   = useState(caretaker.getTodos());

  const refrescar = () => setPerfiles(caretaker.getTodos());

  const mostrarMensaje = (texto, tipo = 'ok') => {
    setMensaje({ texto, tipo });
    setTimeout(() => setMensaje(null), 2000);
  };

  // ── Guardar perfil ────────────────────────────────────────
  const handleGuardar = () => {
    const n = nombre.trim();
    if (!n) {
      mostrarMensaje('Escribe un nombre para el perfil.', 'err');
      return;
    }
    caretaker.guardar(n, selArmadura, selArmas);
    refrescar();
    setNombre('');
    mostrarMensaje(`✅ Perfil "${n}" guardado.`);
  };

  // ── Cargar perfil ─────────────────────────────────────────
  const handleCargar = (nombrePerfil) => {
    const memento = caretaker.cargar(nombrePerfil);
    if (memento) {
      onCargar(memento.getSelArmadura(), memento.getSelArmas());
      mostrarMensaje(`📂 Perfil "${nombrePerfil}" cargado.`);
    }
  };

  // ── Eliminar perfil ───────────────────────────────────────
  const handleEliminar = (nombrePerfil) => {
    caretaker.eliminar(nombrePerfil);
    refrescar();
    mostrarMensaje(`🗑️ Perfil "${nombrePerfil}" eliminado.`, 'err');
  };

  // ── Emojis por slot ───────────────────────────────────────
  const EMOJI_SLOT = {
    casco: '⛑️', pecho: '🦺', botas: '👢',
    espada: '🗡️', arco: '🏹', hacha: '🪓',
  };

  const renderEquipo = (selA, selW) => {
    const items = [
      ...Object.entries(selA).filter(([, v]) => v),
      ...Object.entries(selW).filter(([, v]) => v),
    ];
    if (items.length === 0) return (
      <Text style={styles.emptyEquipo}>Sin equipo</Text>
    );
    return (
      <View style={styles.equipoRow}>
        {items.map(([slot, mat]) => (
          <View key={slot} style={styles.equipoBadge}>
            <Text style={styles.equipoEmoji}>{EMOJI_SLOT[slot]}</Text>
            <Text style={styles.equipoMat}>{mat}</Text>
          </View>
        ))}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>💾 Perfiles guardados</Text>

      {/* ── Input para guardar ──────────────────────────── */}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Nombre del perfil..."
          placeholderTextColor={THEME.textMuted}
          value={nombre}
          onChangeText={setNombre}
          maxLength={24}
        />
        <TouchableOpacity style={styles.saveBtn} onPress={handleGuardar}>
          <Text style={styles.saveBtnText}>Guardar</Text>
        </TouchableOpacity>
      </View>

      {/* ── Mensaje de feedback ─────────────────────────── */}
      {mensaje && (
        <View style={[
          styles.mensajeBox,
          mensaje.tipo === 'err' ? styles.mensajeErr : styles.mensajeOk,
        ]}>
          <Text style={styles.mensajeText}>{mensaje.texto}</Text>
        </View>
      )}

      {/* ── Lista de perfiles ───────────────────────────── */}
      {perfiles.length === 0 ? (
        <View style={styles.emptyBox}>
          <Text style={styles.emptyText}>
            Aún no hay perfiles guardados.{'\n'}
            Equipa a Steve y guarda tu primera build.
          </Text>
        </View>
      ) : (
        perfiles.map(perfil => (
          <View key={perfil.getNombre()} style={styles.perfilCard}>
            {/* Cabecera */}
            <View style={styles.perfilHeader}>
              <View style={{ flex: 1 }}>
                <Text style={styles.perfilNombre}>{perfil.getNombre()}</Text>
                <Text style={styles.perfilFecha}>🕐 {perfil.getFecha()}</Text>
              </View>
              {/* Botones */}
              <View style={styles.perfilBtns}>
                <TouchableOpacity
                  style={styles.loadBtn}
                  onPress={() => handleCargar(perfil.getNombre())}
                >
                  <Text style={styles.loadBtnText}>Cargar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.deleteBtn}
                  onPress={() => handleEliminar(perfil.getNombre())}
                >
                  <Text style={styles.deleteBtnText}>🗑️</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Equipo guardado */}
            {renderEquipo(perfil.getSelArmadura(), perfil.getSelArmas())}
          </View>
        ))
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { marginTop: 4 },
  sectionTitle: {
    color: THEME.primaryLight, fontWeight: '800',
    fontSize: 14, letterSpacing: 0.5, marginBottom: 10,
  },

  // Input
  inputRow: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  input: {
    flex: 1, backgroundColor: THEME.bgCard,
    borderWidth: 1, borderColor: THEME.border,
    borderRadius: 10, paddingHorizontal: 12,
    paddingVertical: 8, color: THEME.text, fontSize: 13,
  },
  saveBtn: {
    backgroundColor: THEME.primaryDark, borderRadius: 10,
    paddingHorizontal: 14, justifyContent: 'center',
    borderWidth: 1, borderColor: THEME.primary,
  },
  saveBtnText: { color: THEME.accent, fontWeight: '700', fontSize: 13 },

  // Mensaje
  mensajeBox: {
    borderRadius: 8, padding: 8,
    marginBottom: 8, borderWidth: 1,
  },
  mensajeOk:   { backgroundColor: '#0A1F0A', borderColor: THEME.primary },
  mensajeErr:  { backgroundColor: '#1A0000', borderColor: THEME.red },
  mensajeText: { color: THEME.text, fontSize: 12, textAlign: 'center' },

  // Empty
  emptyBox: {
    backgroundColor: THEME.bgSection, borderRadius: 10,
    borderWidth: 1, borderColor: THEME.border,
    padding: 16, alignItems: 'center', marginBottom: 8,
  },
  emptyText: { color: THEME.textMuted, fontSize: 12, textAlign: 'center', lineHeight: 20 },

  // Tarjeta de perfil
  perfilCard: {
    backgroundColor: THEME.bgCard, borderRadius: 12,
    borderWidth: 1, borderColor: THEME.primaryDark,
    padding: 12, marginBottom: 10, gap: 8,
  },
  perfilHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  perfilNombre: { color: THEME.accent, fontWeight: '800', fontSize: 14 },
  perfilFecha:  { color: THEME.textMuted, fontSize: 10, marginTop: 2 },
  perfilBtns:   { flexDirection: 'row', gap: 6 },
  loadBtn: {
    backgroundColor: THEME.primaryDark, borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 6,
    borderWidth: 1, borderColor: THEME.primary,
  },
  loadBtnText:   { color: THEME.accent, fontWeight: '700', fontSize: 12 },
  deleteBtn: {
    backgroundColor: '#1A0000', borderRadius: 8,
    paddingHorizontal: 10, paddingVertical: 6,
    borderWidth: 1, borderColor: THEME.red,
  },
  deleteBtnText: { fontSize: 14 },

  // Equipo dentro del perfil
  equipoRow:   { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  equipoBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: THEME.bgSection, borderRadius: 8,
    borderWidth: 1, borderColor: THEME.border,
    paddingHorizontal: 8, paddingVertical: 4,
  },
  equipoEmoji:  { fontSize: 14 },
  equipoMat:    { color: THEME.textMuted, fontSize: 11, fontWeight: '600' },
  emptyEquipo:  { color: THEME.textMuted, fontSize: 11 },
});