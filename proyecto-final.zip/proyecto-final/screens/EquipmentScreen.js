import React from 'react';
import {
  View, Text, ScrollView,
  StyleSheet, StatusBar, TouchableOpacity,
} from 'react-native';

// ── MVVM: ViewModel ──────────────────────────────────────────
import { useEquipamiento, ARMOR_SLOTS, WEAPON_SLOTS } from '../viewmodels/useEquipamiento';

// ── Armas (solo para listar opciones en la UI) ───────────────
import ArmasModule from '../bridge/Armas';
const { ARMAS_POR_TIPO } = ArmasModule;

import THEME         from '../config/theme';
import AvatarPanel   from '../components/AvatarPanel';
import SlotSection   from '../components/SlotSection';
import StatsPanel    from '../components/StatsPanel';
import PerfilesPanel from '../components/PerfilesPanel';

// ────────────────────────────────────────────────────────────
// VISTA PURA — esta pantalla no tiene lógica ni estado propio.
// Todo viene del ViewModel (useEquipamiento).
// ────────────────────────────────────────────────────────────
export default function EquipmentScreen() {

  // ── Consume el ViewModel ─────────────────────────────────
  const {
    selArmadura, selArmas, tab, setTab,
    personaje, monedasLeft, equipados,
    pocasMonedas, sinMonedas,
    caretaker,
    seleccionarArmadura, seleccionarArma,
    resetear, cargarPerfil,
  } = useEquipamiento();

  // ── Render ───────────────────────────────────────────────
  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={THEME.bg} />

      {/* ── Encabezado ──────────────────────────────────── */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>⛏️ Minecraft Armor</Text>
          <Text style={styles.headerSub}>
            Decorator + Bridge + Memento + Factory + MVVM · {equipados}/6 equipado
          </Text>
        </View>
        {equipados > 0 && (
          <TouchableOpacity onPress={resetear} style={styles.resetBtn}>
            <Text style={styles.resetText}>↺ Reset</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* ── Avatar ──────────────────────────────────────── */}
        <AvatarPanel personaje={personaje} />

        {/* ── Advertencias de monedas ─────────────────────── */}
        {pocasMonedas && (
          <View style={styles.warningBox}>
            <Text style={styles.warningText}>
              ⚠️ Pocas monedas ({monedasLeft}). Algunas piezas no disponibles.
            </Text>
          </View>
        )}
        {sinMonedas && (
          <View style={[styles.warningBox, styles.warningRed]}>
            <Text style={styles.warningText}>
              🚫 Sin monedas. Desequipa algo para continuar.
            </Text>
          </View>
        )}

        {/* ── Tabs ────────────────────────────────────────── */}
        <View style={styles.tabs}>
          {[
            { id: 'armadura', label: '🛡️ Armadura' },
            { id: 'armas',    label: '⚔️ Armas'    },
            { id: 'perfiles', label: '💾 Perfiles'  },
          ].map(t => (
            <TouchableOpacity
              key={t.id}
              style={[styles.tab, tab === t.id && styles.tabActive]}
              onPress={() => setTab(t.id)}
            >
              <Text style={[styles.tabText, tab === t.id && styles.tabTextActive]}>
                {t.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* ── Tab: Armadura ───────────────────────────────── */}
        {tab === 'armadura' && (
          <>
            <Text style={styles.sectionTitle}>🛡️ Equipamiento</Text>
            {ARMOR_SLOTS.map(slot => (
              <SlotSection
                key={slot.id}
                slot={slot}
                selectedMaterialNombre={selArmadura[slot.id]}
                monedasRestantes={monedasLeft}
                costoActual={personaje.getCostoTotal()}
                onSelect={seleccionarArmadura}
              />
            ))}
          </>
        )}

        {/* ── Tab: Armas ──────────────────────────────────── */}
        {tab === 'armas' && (
          <>
            <Text style={styles.sectionTitle}>⚔️ Armas</Text>
            {WEAPON_SLOTS.map(slot => {
              const tipoLabel = slot.id.charAt(0).toUpperCase() + slot.id.slice(1);
              const opciones  = ARMAS_POR_TIPO[tipoLabel] || [];
              return (
                <View key={slot.id} style={styles.weaponSlot}>
                  <Text style={styles.weaponSlotTitle}>{slot.emoji} {slot.label}</Text>
                  <View style={styles.weaponOptions}>

                    {/* Opción ninguna */}
                    <TouchableOpacity
                      style={[styles.weaponChip, selArmas[slot.id] === null && styles.weaponChipSelected]}
                      onPress={() => seleccionarArma(slot.id, null)}
                    >
                      <Text style={styles.weaponChipText}>Ninguna</Text>
                    </TouchableOpacity>

                    {/* Opciones por material */}
                    {opciones.map(arma => {
                      const canAfford = monedasLeft >= arma.getCosto() || selArmas[slot.id] === arma.nombre;
                      const selected  = selArmas[slot.id] === arma.nombre;
                      return (
                        <TouchableOpacity
                          key={arma.nombre}
                          style={[
                            styles.weaponChip,
                            selected && styles.weaponChipSelected,
                            !canAfford && !selected && styles.weaponChipDisabled,
                          ]}
                          onPress={() => (canAfford || selected)
                            ? seleccionarArma(slot.id, selected ? null : arma.nombre)
                            : null}
                          disabled={!canAfford && !selected}
                        >
                          <Text style={[styles.weaponChipEmoji, !canAfford && !selected && { opacity: 0.3 }]}>
                            {arma.emoji}
                          </Text>
                          <Text style={[styles.weaponChipText, !canAfford && !selected && styles.weaponChipTextDisabled]}>
                            {arma.nombre}
                          </Text>
                          <Text style={[styles.weaponChipStat, !canAfford && !selected && styles.weaponChipTextDisabled]}>
                            ⚔️{arma.getDanio()} · 🪙{arma.getCosto()}
                          </Text>
                          {selected && <View style={[styles.rarityDot, { backgroundColor: arma.rarityColor }]} />}
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </View>
              );
            })}
          </>
        )}

        {/* ── Tab: Perfiles (Memento) ──────────────────────── */}
        {tab === 'perfiles' && (
          <PerfilesPanel
            caretaker={caretaker}
            selArmadura={selArmadura}
            selArmas={selArmas}
            onCargar={cargarPerfil}
          />
        )}

        {/* ── Estadísticas ────────────────────────────────── */}
        <StatsPanel personaje={personaje} />

        {/* ── Leyenda de patrones ─────────────────────────── */}
        <View style={styles.legendBox}>
          <Text style={styles.legendTitle}>📖 Patrones aplicados</Text>
          <Text style={styles.legendText}>
            <Text style={{ color: THEME.primary }}>Decorator: </Text>
            cada pieza y arma envuelve al personaje sumando stats por capas.
          </Text>
          <Text style={styles.legendText}>
            <Text style={{ color: THEME.gold }}>Bridge: </Text>
            calcularDef() y calcularDanio() delegan al IMaterial/IArma concreto.
          </Text>
          <Text style={styles.legendText}>
            <Text style={{ color: '#44C8D8' }}>Memento: </Text>
            guarda y restaura configuraciones completas de Steve como perfiles.
          </Text>
          <Text style={styles.legendText}>
            <Text style={{ color: '#FF9944' }}>Factory Method: </Text>
            centraliza la creación de piezas y armas según slot y material.
          </Text>
          <Text style={styles.legendText}>
            <Text style={{ color: '#CC44FF' }}>MVVM: </Text>
            useEquipamiento separa la lógica de la vista completamente.
          </Text>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: THEME.bg },
  header: {
    paddingTop: 50, paddingBottom: 14, paddingHorizontal: 20,
    borderBottomWidth: 1, borderBottomColor: THEME.border,
    backgroundColor: THEME.bgCard,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  headerTitle: { fontSize: 20, fontWeight: '900', color: THEME.accent, letterSpacing: 1 },
  headerSub:   { fontSize: 10, color: THEME.textMuted, marginTop: 3 },
  resetBtn: {
    backgroundColor: THEME.bgSection, borderWidth: 1,
    borderColor: THEME.primaryDark, paddingHorizontal: 14,
    paddingVertical: 8, borderRadius: 8,
  },
  resetText: { color: THEME.red, fontWeight: '700', fontSize: 13 },
  scroll:    { padding: 16 },
  tabs:      { flexDirection: 'row', gap: 6, marginBottom: 14, marginTop: 2 },
  tab: {
    flex: 1, paddingVertical: 9, alignItems: 'center',
    borderRadius: 10, backgroundColor: THEME.bgSection,
    borderWidth: 1, borderColor: THEME.border,
  },
  tabActive:     { backgroundColor: THEME.primaryDark, borderColor: THEME.primary },
  tabText:       { color: THEME.textMuted, fontWeight: '700', fontSize: 11 },
  tabTextActive: { color: THEME.accent },
  sectionTitle: {
    color: THEME.primaryLight, fontWeight: '800',
    fontSize: 14, letterSpacing: 0.5, marginBottom: 10,
  },
  weaponSlot: {
    backgroundColor: THEME.bgCard, borderRadius: 12,
    borderWidth: 1, borderColor: THEME.border,
    padding: 12, marginBottom: 10,
  },
  weaponSlotTitle:        { color: THEME.text, fontWeight: '800', fontSize: 13, marginBottom: 10 },
  weaponOptions:          { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  weaponChip: {
    paddingHorizontal: 12, paddingVertical: 8,
    backgroundColor: THEME.bgSection, borderRadius: 10,
    borderWidth: 1, borderColor: THEME.border,
    alignItems: 'center', gap: 3, minWidth: 72,
  },
  weaponChipSelected:     { backgroundColor: THEME.selected, borderColor: THEME.primary },
  weaponChipDisabled:     { borderColor: THEME.border, opacity: 0.4 },
  weaponChipEmoji:        { fontSize: 18 },
  weaponChipText:         { color: THEME.text, fontWeight: '700', fontSize: 12 },
  weaponChipTextDisabled: { color: THEME.disabledText },
  weaponChipStat:         { color: THEME.textMuted, fontSize: 10 },
  rarityDot:              { width: 6, height: 6, borderRadius: 3, marginTop: 2 },
  warningBox: {
    backgroundColor: '#1A1200', borderWidth: 1,
    borderColor: '#8B6914', borderRadius: 8,
    padding: 10, marginBottom: 12,
  },
  warningRed:  { backgroundColor: '#1A0000', borderColor: THEME.red },
  warningText: { color: '#FFD700', fontSize: 12 },
  legendBox: {
    marginTop: 12, backgroundColor: THEME.bgSection,
    borderRadius: 10, borderWidth: 1,
    borderColor: THEME.primaryDark, padding: 14, gap: 6,
  },
  legendTitle: { color: THEME.primary, fontWeight: '700', fontSize: 13, marginBottom: 4 },
  legendText:  { color: THEME.textMuted, fontSize: 12, lineHeight: 18 },
});