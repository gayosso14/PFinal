import PiezasModule from '../decorator/Piezas';
const { CascoDecorador, PechoDecorador, BootasDecorador } = PiezasModule;

import MatModule from '../bridge/Materiales';
const { cuero, hierro, diamante } = MatModule;

class PiezaFactory {

  static crearMaterial(nombre) {
    switch (nombre) {
      case 'Cuero':    return cuero;
      case 'Hierro':   return hierro;
      case 'Diamante': return diamante;
      default:
        throw new Error(`Material desconocido: ${nombre}`);
    }
  }

  static crear(personaje, slot, materialNombre) {
    const material = PiezaFactory.crearMaterial(materialNombre);

    switch (slot) {
      case 'casco': return new CascoDecorador(personaje, material);
      case 'pecho': return new PechoDecorador(personaje, material);
      case 'botas': return new BootasDecorador(personaje, material);
      default:
        throw new Error(`Slot de armadura desconocido: ${slot}`);
    }
  }
}

export default PiezaFactory;