import TiposArmaModule from '../decorator/TiposArma';
const { EspadaDecorador, ArcoDecorador, HachaDecorador } = TiposArmaModule;

import ArmasModule from '../bridge/Armas';
const { ARMAS_POR_TIPO } = ArmasModule;

class ArmaFactory {

  static crearArma(slot, materialNombre) {
    const tipoLabel = slot.charAt(0).toUpperCase() + slot.slice(1); // 'espada' → 'Espada'
    const lista     = ARMAS_POR_TIPO[tipoLabel] || [];
    const arma      = lista.find(a => a.nombre === materialNombre);

    if (!arma) throw new Error(`Arma desconocida: ${tipoLabel} de ${materialNombre}`);
    return arma;
  }

  static crear(personaje, slot, materialNombre) {
    const arma = ArmaFactory.crearArma(slot, materialNombre);

    switch (slot) {
      case 'espada': return new EspadaDecorador(personaje, arma);
      case 'arco':   return new ArcoDecorador(personaje, arma);
      case 'hacha':  return new HachaDecorador(personaje, arma);
      default:
        throw new Error(`Slot de arma desconocido: ${slot}`);
    }
  }
}

export default ArmaFactory;